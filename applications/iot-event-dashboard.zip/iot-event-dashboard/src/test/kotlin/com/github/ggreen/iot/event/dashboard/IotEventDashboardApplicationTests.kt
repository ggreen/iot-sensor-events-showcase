package com.github.ggreen.iot.event.dashboard

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class IotEventDashboardApplicationTests {

	@Test
	fun contextLoads() {
	}

}
