package com.github.ggreen.iot.event.dashboard

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class IotEventDashboardApplication

fun main(args: Array<String>) {
	runApplication<IotEventDashboardApplication>(*args)
}
